# CS194 Project 2 Readme

The python notebook goes through the project in the order that its listed on the website. I don't really think it should require any documentation to use. It should be clear what all the functions do and how they are used. That being said I did use photoshow to create masks for part 2.4 and to align the images for part 2.2.

Requirements are listed in the first code block.